package com.novatv.receiver;

import android.app.ActivityManager;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Random;

public class TvMainActivity extends AppCompatActivity {

    private WebView webView;
    private String currentSecurityPin = "";
    private final Instrumentation instrumentation = new Instrumentation();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                String tvModel = Build.MODEL != null ? Build.MODEL : "ATMACA_SmartTV";
                evalJs("if(window.setNativeTvModel) window.setNativeTvModel('" + tvModel.replace("'", "") + "');");
            }
        });

        webView.loadUrl("file:///android_asset/tv_ui.html");

        startUdpDiscoveryAndMouseServer();
        startLocalHttpControlServer();
    }

    private void evalJs(final String script) {
        runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                webView.evaluateJavascript(script, null);
            } else {
                webView.loadUrl("javascript:" + script);
            }
        });
    }

    // 1. UDP Server on Port 8988 for Zero-Config Radar Discovery + 60FPS Smooth Air Mouse
    private void startUdpDiscoveryAndMouseServer() {
        new Thread(() -> {
            try {
                DatagramSocket socket = new DatagramSocket(8988, InetAddress.getByName("0.0.0.0"));
                socket.setBroadcast(true);
                byte[] buf = new byte[1024];
                while (!isFinishing()) {
                    DatagramPacket packet = new DatagramPacket(buf, buf.length);
                    socket.receive(packet);
                    String msg = new String(packet.getData(), 0, packet.getLength(), StandardCharsets.UTF_8);

                    if (msg.equals("NOVATV_DISCOVER_REQUEST")) {
                        String model = Build.MODEL != null ? Build.MODEL : "ATMACA_SmartTV";
                        byte[] reply = ("NOVATV_HERE:" + model).getBytes(StandardCharsets.UTF_8);
                        DatagramPacket resp = new DatagramPacket(reply, reply.length, packet.getAddress(), packet.getPort());
                        socket.send(resp);
                    } else if (msg.startsWith("MOUSE:")) {
                        String[] parts = msg.substring(6).split(",");
                        if (parts.length == 2) {
                            evalJs("if(window.onSmoothMouseMove) window.onSmoothMouseMove(" + parts[0] + "," + parts[1] + ");");
                        }
                    }
                }
            } catch (Exception ignored) {}
        }).start();
    }

    // 2. Local HTTP Control Server on Port 8989 (Zero Latency Local Wi-Fi Control)
    private void startLocalHttpControlServer() {
        new Thread(() -> {
            try {
                ServerSocket serverSocket = new ServerSocket(8989);
                while (!isFinishing()) {
                    Socket client = serverSocket.accept();
                    handleClientSocket(client);
                }
            } catch (Exception ignored) {}
        }).start();
    }

    private void handleClientSocket(final Socket client) {
        new Thread(() -> {
            try {
                BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8));
                String requestLine = in.readLine();
                if (requestLine == null) { client.close(); return; }

                String[] reqParts = requestLine.split(" ");
                String path = reqParts.length > 1 ? reqParts[1] : "/";

                int contentLength = 0;
                String headerLine;
                while ((headerLine = in.readLine()) != null && !headerLine.isEmpty()) {
                    if (headerLine.toLowerCase().startsWith("content-length:")) {
                        contentLength = Integer.parseInt(headerLine.substring(15).trim());
                    }
                }

                StringBuilder bodyBuilder = new StringBuilder();
                if (contentLength > 0) {
                    char[] bodyChars = new char[contentLength];
                    in.read(bodyChars, 0, contentLength);
                    bodyBuilder.append(bodyChars);
                }
                String body = bodyBuilder.toString();
                String responseBody = "OK";

                if (path.startsWith("/pair")) {
                    evalJs("if(window.onPhonePaired) window.onPhonePaired();");
                }
                else if (path.startsWith("/key?code=")) {
                    int keyCode = Integer.parseInt(path.substring("/key?code=".length()));
                    executeSystemKeyEvent(keyCode);
                }
                else if (path.startsWith("/hide_cursor")) {
                    evalJs("if(window.hideMouseCursor) window.hideMouseCursor();");
                }
                else if (path.startsWith("/text")) {
                    injectSystemText(body);
                }
                else if (path.startsWith("/apps")) {
                    boolean includeSys = path.contains("sys=1");
                    responseBody = getInstalledAppsJson(includeSys);
                }
                else if (path.startsWith("/launch?pkg=")) {
                    String pkg = URLDecoder.decode(path.substring("/launch?pkg=".length()), "UTF-8");
                    launchPackageByName(pkg);
                }
                else if (path.startsWith("/clean")) {
                    responseBody = performRealSystemClean();
                }
                else if (path.startsWith("/request_pin")) {
                    currentSecurityPin = String.format("%04d", new Random().nextInt(9000) + 1000);
                    evalJs("if(window.showSecurityPinPopup) window.showSecurityPinPopup('" + currentSecurityPin + "');");
                }
                else if (path.startsWith("/verify_pin")) {
                    if (path.contains("pin=" + currentSecurityPin)) {
                        evalJs("if(window.hideSecurityPinPopup) window.hideSecurityPinPopup(true);");
                        responseBody = "OK";
                    } else {
                        responseBody = "INVALID";
                    }
                }
                else if (path.startsWith("/ai_exec")) {
                    executeSmartAiCommand(body);
                }

                byte[] respBytes = responseBody.getBytes(StandardCharsets.UTF_8);
                OutputStream out = client.getOutputStream();
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nAccess-Control-Allow-Origin: *\r\nContent-Length: " + respBytes.length + "\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                out.write(respBytes);
                out.flush();
                client.close();
            } catch (Exception ignored) {}
        }).start();
    }

    private void executeSystemKeyEvent(final int keyCode) {
        new Thread(() -> {
            try {
                AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
                if (keyCode == 24 && audio != null) {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
                    return;
                } else if (keyCode == 25 && audio != null) {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
                    return;
                } else if (keyCode == 164 && audio != null) {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI);
                    return;
                }
                Runtime.getRuntime().exec("input keyevent " + keyCode);
                instrumentation.sendKeyDownUpSync(keyCode);
            } catch (Exception ignored) {}
        }).start();
    }

    private void injectSystemText(final String text) {
        new Thread(() -> {
            try {
                String safe = text.replace(" ", "%s");
                Runtime.getRuntime().exec(new String[]{"sh", "-c", "input text '" + safe + "' && input keyevent 66"});
            } catch (Exception ignored) {}
        }).start();
    }

    private String getInstalledAppsJson(boolean includeSystem) {
        JSONArray arr = new JSONArray();
        try {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            for (ApplicationInfo app : apps) {
                boolean isSys = (app.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                if (!includeSystem && isSys) continue;
                if (pm.getLaunchIntentForPackage(app.packageName) != null || includeSystem) {
                    JSONObject obj = new JSONObject();
                    obj.put("name", pm.getApplicationLabel(app).toString());
                    obj.put("pkg", app.packageName);
                    obj.put("sys", isSys);
                    arr.put(obj);
                }
            }
        } catch (Exception ignored) {}
        return arr.toString();
    }

    private void launchPackageByName(String pkg) {
        try {
            if (pkg.equals("android.settings.SETTINGS")) {
                Intent i = new Intent(Settings.ACTION_SETTINGS);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return;
            }
            PackageManager pm = getPackageManager();
            Intent intent = pm.getLaunchIntentForPackage(pkg);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        } catch (Exception ignored) {}
    }

    private String performRealSystemClean() {
        int killedCount = 0;
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> packages = pm.getInstalledApplications(0);
            for (ApplicationInfo pkgInfo : packages) {
                if (!pkgInfo.packageName.equals(getPackageName())) {
                    if (am != null) {
                        am.killBackgroundProcesses(pkgInfo.packageName);
                        killedCount++;
                    }
                }
            }
            System.gc();
        } catch (Exception ignored) {}
        evalJs("if(window.showCleanSuccessToast) window.showCleanSuccessToast();");
        return "Cleaned " + killedCount + " processes";
    }

    // Dynamic Universal AI Intent Engine: Matches ANY installed app on TV or system action!
    private void executeSmartAiCommand(final String speech) {
        if (speech == null || speech.trim().isEmpty()) return;
        final String s = speech.trim().toLowerCase(Locale.ROOT);

        new Thread(() -> {
            try {
                // 1. Check if user is asking to clean/boost TV
                if (s.contains("نظف") || s.contains("سرع") || s.contains("رام") || s.contains("كاش")) {
                    performRealSystemClean();
                    return;
                }

                // 2. Check if user is asking for Settings
                if (s.contains("إعدادات") || s.contains("اعدادات") || s.contains("واي فاي") || s.contains("شبكة")) {
                    launchPackageByName("android.settings.SETTINGS");
                    return;
                }

                // 3. Dynamically search ALL installed apps on the TV by their Arabic/English label!
                PackageManager pm = getPackageManager();
                List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
                for (ApplicationInfo app : apps) {
                    String label = pm.getApplicationLabel(app).toString().toLowerCase(Locale.ROOT);
                    if (label.length() >= 2 && s.contains(label)) {
                        launchPackageByName(app.packageName);
                        return;
                    }
                }

                // 4. Fallback for YouTube / Play Store / Browser search & play
                if (s.contains("يوتيوب") || s.contains("شغل") || s.contains("مقطع") || s.contains("فيديو")) {
                    String query = s.replaceAll("ادخل|افتح|على|لي|يوتيوب|وابحث|ابحث|عن|وشغل|شغل|مقطع|فيديو|إياه", "").trim();
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else if (s.contains("متجر") || s.contains("بلاي") || s.contains("ثبت") || s.contains("نزل")) {
                    String query = s.replaceAll("ادخل|افتح|على|لي|المتجر|متجر|بلاي|وابحث|ابحث|عن|تطبيق|برنامج|وثبت|ثبت|نزل", "").trim();
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(query)));
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                }
            } catch (Exception ignored) {}
        }).start();
    }
}
