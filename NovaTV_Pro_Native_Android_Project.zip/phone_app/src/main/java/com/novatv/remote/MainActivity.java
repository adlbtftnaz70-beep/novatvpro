package com.novatv.remote;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.KeyEvent;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private String connectedTvIp = "";
    private int connectedTvPort = 8989;
    private SpeechRecognizer speechRecognizer;
    private DatagramSocket udpMouseSocket;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.addJavascriptInterface(new NativePhoneBridge(), "NativePhone");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    request.grant(request.getResources());
                }
            }
        });

        checkAudioPermission();
        initNativeSpeechRecognizer();
        try {
            udpMouseSocket = new DatagramSocket();
        } catch (Exception ignored) {}

        webView.loadUrl("file:///android_asset/phone_ui.html");
    }

    private void checkAudioPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, 101);
        }
    }

    private void initNativeSpeechRecognizer() {
        runOnUiThread(() -> {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
                speechRecognizer.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle params) {}
                    @Override public void onBeginningOfSpeech() {}
                    @Override public void onRmsChanged(float rmsdB) {}
                    @Override public void onBufferReceived(byte[] buffer) {}
                    @Override public void onEndOfSpeech() {}
                    @Override public void onError(int error) {
                        evalJs("if(window.onNativeVoiceError) window.onNativeVoiceError(" + error + ");");
                    }
                    @Override
                    public void onResults(Bundle results) {
                        ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches != null && !matches.isEmpty()) {
                            String text = matches.get(0).replace("'", "\'");
                            evalJs("if(window.onNativeVoiceResult) window.onNativeVoiceResult('" + text + "', true);");
                        }
                    }
                    @Override
                    public void onPartialResults(Bundle partialResults) {
                        ArrayList<String> matches = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (matches != null && !matches.isEmpty()) {
                            String text = matches.get(0).replace("'", "\'");
                            evalJs("if(window.onNativeVoiceResult) window.onNativeVoiceResult('" + text + "', false);");
                        }
                    }
                    @Override public void onEvent(int eventType, Bundle params) {}
                });
            }
        });
    }

    private void evalJs(final String script) {
        runOnUiThread(() -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                webView.evaluateJavascript(script, null);
            } else {
                webView.loadUrl("javascript:" + script);
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            new NativePhoneBridge().sendKey(24);
            return true;
        } else if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            new NativePhoneBridge().sendKey(25);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public class NativePhoneBridge {

        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.vibrate(ms);
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void startRadarScan() {
            new Thread(() -> {
                try {
                    DatagramSocket socket = new DatagramSocket();
                    socket.setBroadcast(true);
                    socket.setSoTimeout(3000);
                    byte[] sendData = "NOVATV_DISCOVER_REQUEST".getBytes(StandardCharsets.UTF_8);
                    DatagramPacket sendPacket = new DatagramPacket(
                            sendData, sendData.length, InetAddress.getByName("255.255.255.255"), 8988);
                    socket.send(sendPacket);

                    byte[] recvBuf = new byte[1024];
                    DatagramPacket receivePacket = new DatagramPacket(recvBuf, recvBuf.length);
                    socket.receive(receivePacket);

                    String response = new String(receivePacket.getData(), 0, receivePacket.getLength(), StandardCharsets.UTF_8);
                    String tvIp = receivePacket.getAddress().getHostAddress();
                    socket.close();

                    if (response.startsWith("NOVATV_HERE:")) {
                        String tvModel = response.substring("NOVATV_HERE:".length());
                        evalJs("if(window.onTvDiscovered) window.onTvDiscovered('" + tvIp + "', '" + tvModel.replace("'", "") + "');");
                    }
                } catch (Exception e) {
                    evalJs("if(window.onTvScanTimeout) window.onTvScanTimeout();");
                }
            }).start();
        }

        @JavascriptInterface
        public void connectToTv(String ip) {
            connectedTvIp = ip;
            sendHttpCommand("/pair", "{"phoneModel":"" + Build.MODEL + ""}", response -> {
                evalJs("if(window.onTvPairedSuccess) window.onTvPairedSuccess('" + ip + "');");
            });
        }

        @JavascriptInterface
        public void sendKey(int keyCode) {
            sendHttpCommand("/key?code=" + keyCode, "", null);
        }

        @JavascriptInterface
        public void sendMouseMove(float dx, float dy) {
            if (connectedTvIp == null || connectedTvIp.isEmpty()) return;
            new Thread(() -> {
                try {
                    String msg = "MOUSE:" + dx + "," + dy;
                    byte[] data = msg.getBytes(StandardCharsets.UTF_8);
                    DatagramPacket pkt = new DatagramPacket(data, data.length, InetAddress.getByName(connectedTvIp), 8988);
                    udpMouseSocket.send(pkt);
                } catch (Exception ignored) {}
            }).start();
        }

        @JavascriptInterface
        public void hideMouseCursor() {
            sendHttpCommand("/hide_cursor", "", null);
        }

        @JavascriptInterface
        public void sendText(String text) {
            sendHttpCommand("/text", text, null);
        }

        @JavascriptInterface
        public void fetchInstalledApps(boolean includeSystem) {
            sendHttpCommand("/apps?sys=" + (includeSystem ? "1" : "0"), "", response -> {
                String safeJson = response.replace("\", "\\").replace("'", "\'");
                evalJs("if(window.onInstalledAppsReceived) window.onInstalledAppsReceived('" + safeJson + "', " + includeSystem + ");");
            });
        }

        @JavascriptInterface
        public void launchApp(String packageName) {
            sendHttpCommand("/launch?pkg=" + packageName, "", null);
        }

        @JavascriptInterface
        public void cleanTvRam() {
            sendHttpCommand("/clean", "", response -> {
                evalJs("if(window.onTvCleanComplete) window.onTvCleanComplete('" + response.replace("'", "") + "');");
            });
        }

        @JavascriptInterface
        public void requestApkPin(String apkName) {
            sendHttpCommand("/request_pin?name=" + UriEncode(apkName), "", null);
        }

        @JavascriptInterface
        public void verifyApkPin(String pinCode, String apkName) {
            sendHttpCommand("/verify_pin?pin=" + UriEncode(pinCode) + "&name=" + UriEncode(apkName), "", response -> {
                boolean ok = response != null && response.contains("OK");
                evalJs("if(window.onPinVerifiedResult) window.onPinVerifiedResult(" + ok + ", '" + apkName.replace("'", "") + "');");
            });
        }

        @JavascriptInterface
        public void captureScreenshot() {
            sendHttpCommand("/screenshot", "", response -> {
                evalJs("if(window.onScreenshotReceived) window.onScreenshotReceived('" + response.trim() + "');");
            });
        }

        @JavascriptInterface
        public void executeAiMacro(String spokenSentence) {
            sendHttpCommand("/ai_exec", spokenSentence, response -> {
                evalJs("if(window.onAiMacroDone) window.onAiMacroDone('" + response.replace("'", "") + "');");
            });
        }

        @JavascriptInterface
        public void startNativeMic() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA");
                    intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                    intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500);
                    if (speechRecognizer != null) {
                        speechRecognizer.startListening(intent);
                    }
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public void stopNativeMic() {
            runOnUiThread(() -> {
                try {
                    if (speechRecognizer != null) speechRecognizer.stopListening();
                } catch (Exception ignored) {}
            });
        }
    }

    private String UriEncode(String s) {
        try {
            return java.net.URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private interface HttpCallback {
        void onResult(String response);
    }

    private void sendHttpCommand(final String path, final String body, final HttpCallback callback) {
        if (connectedTvIp == null || connectedTvIp.isEmpty()) return;
        new Thread(() -> {
            try {
                URL url = new URL("http://" + connectedTvIp + ":" + connectedTvPort + path);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(1500);
                conn.setReadTimeout(2500);
                if (body != null && !body.isEmpty()) {
                    conn.setRequestMethod("POST");
                    conn.setDoOutput(true);
                    byte[] out = body.getBytes(StandardCharsets.UTF_8);
                    OutputStream os = conn.getOutputStream();
                    os.write(out);
                    os.flush();
                    os.close();
                } else {
                    conn.setRequestMethod("GET");
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                if (callback != null) callback.onResult(sb.toString());
            } catch (Exception ignored) {}
        }).start();
    }
}
